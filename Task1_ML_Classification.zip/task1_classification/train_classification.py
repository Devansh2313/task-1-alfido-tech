from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, ConfusionMatrixDisplay, RocCurveDisplay,
                             classification_report)
import joblib

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)
data = load_breast_cancer(as_frame=True)
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
models = {
    "logistic_regression": Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
        ("model", LogisticRegression(max_iter=3000, random_state=42))
    ]),
    "random_forest": Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", RandomForestClassifier(n_estimators=300, random_state=42,
                                         class_weight="balanced"))
    ])
}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
results = {}
for name, model in models.items():
    cv_result = cross_validate(model, X_train, y_train, cv=cv,
        scoring={"accuracy":"accuracy", "precision":"precision", "recall":"recall",
                 "f1":"f1", "roc_auc":"roc_auc"})
    results[name] = {f"cv_{metric}_mean": float(np.mean(cv_result[f"test_{metric}"]))
                     for metric in ["accuracy","precision","recall","f1","roc_auc"]}
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    results[name].update({
        "test_accuracy": float(accuracy_score(y_test, pred)),
        "test_precision": float(precision_score(y_test, pred, zero_division=0)),
        "test_recall": float(recall_score(y_test, pred, zero_division=0)),
        "test_f1": float(f1_score(y_test, pred, zero_division=0)),
        "test_roc_auc": float(roc_auc_score(y_test, proba))
    })
    if name == "random_forest":
        joblib.dump({"model": model, "feature_names": list(X.columns),
                     "target_names": list(data.target_names)},
                    OUT / "breast_cancer_model.joblib")
        ConfusionMatrixDisplay.from_estimator(model, X_test, y_test)
        plt.tight_layout(); plt.savefig(OUT / "confusion_matrix.png", dpi=160); plt.close()
        RocCurveDisplay.from_estimator(model, X_test, y_test)
        plt.tight_layout(); plt.savefig(OUT / "roc_curve.png", dpi=160); plt.close()
pd.DataFrame(results).T.to_csv(OUT / "metrics.csv")
(OUT / "metrics.json").write_text(json.dumps(results, indent=2))
print(pd.DataFrame(results).T.round(4))
print("\nRandom Forest classification report:")
print(classification_report(y_test, models["random_forest"].predict(X_test),
                            target_names=data.target_names))
print(f"Saved model and plots in {OUT.resolve()}")
