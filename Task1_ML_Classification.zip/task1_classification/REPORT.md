# Task 1 — ML Classification Project

## Objective
Compare Logistic Regression and Random Forest on the Wisconsin Diagnostic Breast Cancer dataset.

## Method
- Loaded the dataset from scikit-learn.
- Split data into 80% training and 20% test sets using stratification and a fixed random seed.
- Used median imputation; standardized features for Logistic Regression.
- Compared both algorithms with 5-fold stratified cross-validation.
- Reported accuracy, precision, recall, F1, and ROC-AUC on the held-out test set.
- Saved a confusion matrix, ROC curve, metrics CSV/JSON, and Random Forest pipeline.

## Results
Run `python train_classification.py`. The script prints and saves the actual metrics. Do not copy invented scores into a report; insert the values from `outputs/metrics.csv` after running.

## Model selection
Choose the model using cross-validation and held-out test metrics together, not accuracy alone. In a medical screening context, false negatives can be costly, so recall and the confusion matrix deserve particular attention. This educational model is not intended for clinical diagnosis.

## Limitations
This is a standard benchmark dataset. Its performance does not establish performance on other hospitals, populations, or imaging/lab workflows.
